McQueen Tattoo Studio — Build 006 realism sweep

Deploy to Netlify by uploading this folder or the ZIP. No build command required.

Changes:
- Photorealistic castle-gate entrance with cyan electrical overlay and McQueen formation.
- Studio scene is now the interface: no visible rectangular UI layered over the objects.
- Desktop click zones tightly follow the three wall frames, library and tattoo chair using clipped shapes.
- Mobile uses a compact dock because the background crop changes object geometry.
- About / awards / training open as framed gallery exhibits rather than generic cards.
- Portfolio opens as a textured two-page leather-bound book.
- Enquiry opens as a torn parchment scroll with a wax-seal style preview action.
- Tattoo concept studio upgraded with a more anatomical generic front/back model.

Private demo only. Portfolio images are Instagram screenshot crops and biography/training claims remain placeholders pending Gigi's approval.

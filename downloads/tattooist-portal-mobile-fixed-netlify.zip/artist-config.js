/*
  TATTOOIST PORTAL BLUEPRINT — CLIENT CONFIG
  -------------------------------------------
  For each new tattooist, duplicate this entire folder and edit ONLY this file,
  assets/portfolio.json, and the images inside assets/portfolio/.

  This copy is pre-filled for Gigi McQueen as the first-client demo.
*/
window.TATTOOIST_CONFIG = {
  artistName: "Gigi McQueen",
  studioName: "McQueen Tattoo Studio",
  shortName: "McQueen",
  tagline: "Art • Energy • Precision",
  enquiryHeading: "Start an enquiry",
  enquiryIntro: "Tell Gigi what you have in mind and give enough detail for the studio to understand the enquiry before getting back to you.",
  aboutHeading: "Meet Gigi McQueen",
  aboutText: "This is the artist profile area. Replace this with Gigi's own approved story, artistic philosophy, preferred styles, influences and what she wants clients to know before booking.",
  styles: ["Black & grey realism", "Fine line", "Floral / botanical", "Mythology", "Portrait / character", "Other / not sure yet"],
  placements: ["Arm", "Leg", "Chest", "Back", "Hand", "Neck", "Other"],
  availability: ["Weekdays", "Weekends", "Flexible"],
  budgets: ["Under £200", "£200–£400", "£400–£800", "£800+", "Discuss with artist"],
  trainingEnabled: true,
  trainingHeading: "Train With Me",
  trainingText: "Use this section for Gigi's approved training offer: who it is for, what she teaches, how training works, expected experience level and availability.",
  trainingTypes: ["Beginner training", "Skills development", "Mentoring", "Need guidance"],
  awardsHeading: "Awards & Training",
  awardsText: "Use this area for verified awards, qualifications, conventions, training and professional milestones. Do not publish unverified credentials.",
  awards: [
    { title: "Award / Milestone", detail: "Replace with a verified award, year and event." },
    { title: "Training / Qualification", detail: "Replace with verified training or certification." },
    { title: "Professional Milestone", detail: "Replace with a convention, guest spot or major achievement." }
  ],
  portfolioHeading: "Selected Work",
  portfolioIntro: "Explore the artist's work. Use the filters to browse by placement.",
  social: {
    instagram: "https://www.instagram.com/gigi_mcqueen"
  },
  colours: {
    accent: "#d7ad71",
    accentSoft: "#f1d7ad",
    electric: "#67e8ff"
  }
};

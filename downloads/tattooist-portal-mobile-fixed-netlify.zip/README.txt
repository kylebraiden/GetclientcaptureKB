Tattooist Portal Blueprint V6 — Mobile Fill Fix

Changes:
- Reverted mobile artwork from contain to cover so it fills the phone screen.
- Reframed the mobile studio toward the right side so the library/bookcase remains visible.
- Kept mobile navigation independent of image hotspots.
- Added a small integrated Library cue on mobile for immediate discoverability.
- Retained Android/iOS dynamic viewport handling.

Upload this folder/ZIP directly to Netlify.
